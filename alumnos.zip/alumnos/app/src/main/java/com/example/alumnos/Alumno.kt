package com.example.alumnos.models

data class Alumno(
    val nombre: String,
    val cuenta: String,
    val correo: String,
    val imageResource: Int
)
