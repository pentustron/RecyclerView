package com.example.alumnos

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.alumnos.adapters.AlumnoAdapter
import com.example.alumnos.models.Alumno
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AlumnoAdapter
    private lateinit var alumnosList: MutableList<Alumno>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        alumnosList = mutableListOf(
            Alumno("Juan Perez", "12345", "juan.perez@mail.com", R.drawable.ic_launcher_foreground),
            Alumno("Ana Garcia", "54321", "ana.garcia@mail.com", R.drawable.ic_launcher_foreground)
        )

        recyclerView = findViewById(R.id.recyclerViewAlumnos)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = AlumnoAdapter(alumnosList)
        recyclerView.adapter = adapter

        val btnAgregar: FloatingActionButton = findViewById(R.id.btnAgregar)
        btnAgregar.setOnClickListener {
            // Aquí puedes implementar el código para agregar un nuevo alumno
            val nuevoAlumno = Alumno("Nuevo Alumno", "00000", "nuevo.alumno@mail.com", R.drawable.ic_launcher_foreground)
            alumnosList.add(nuevoAlumno)
            adapter.notifyDataSetChanged()
        }
    }
}
