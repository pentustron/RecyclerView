package com.example.alumnos.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.alumnos.R
import com.example.alumnos.models.Alumno

class AlumnoAdapter(private val alumnosList: List<Alumno>) : RecyclerView.Adapter<AlumnoAdapter.AlumnoViewHolder>() {

    class AlumnoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nombreTextView: TextView = itemView.findViewById(R.id.textViewNombre)
        val cuentaTextView: TextView = itemView.findViewById(R.id.textViewCuenta)
        val correoTextView: TextView = itemView.findViewById(R.id.textViewCorreo)
        val imageView: ImageView = itemView.findViewById(R.id.imageViewAlumno)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlumnoViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.alumno_item, parent, false)
        return AlumnoViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: AlumnoViewHolder, position: Int) {
        val alumno = alumnosList[position]
        holder.nombreTextView.text = alumno.nombre
        holder.cuentaTextView.text = alumno.cuenta
        holder.correoTextView.text = alumno.correo
        holder.imageView.setImageResource(alumno.imageResource)
    }

    override fun getItemCount() = alumnosList.size
}
